<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <main>
    <h1>CitiesApp</h1>
    <RouterLink to="/cities">CIDADES</RouterLink>
  </main>
</template>
